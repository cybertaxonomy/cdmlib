
/**
 *
 * Abstraction for handling fields of SQLXML data type.
 *
 */
package org.springframework.jdbc.support.xml;

