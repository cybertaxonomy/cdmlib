
/**
 *
 * Context metadata abstraction for the configuration and execution of a stored procedure call.
 *
 */
package org.springframework.jdbc.core.metadata;

