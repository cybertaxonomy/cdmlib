
/**
 *
 * Provides the core JDBC framework, based on JdbcTemplate
 * and its associated callback interfaces and helper objects.
 *
 */
package org.springframework.jdbc.core;

