
/**
 *
 * Provides a strategy for looking up JDBC DataSources by name.
 *
 */
package org.springframework.jdbc.datasource.lookup;

