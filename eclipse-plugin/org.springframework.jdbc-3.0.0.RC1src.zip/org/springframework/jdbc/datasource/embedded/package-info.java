
/**
 *
 * Provides extensible support for creating embedded database instances.
 * HSQL in-memory support provided natively
 *
 */
package org.springframework.jdbc.datasource.embedded;

