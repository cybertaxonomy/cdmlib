
/**
 *
 * Support classes for Spring's resource abstraction.
 * Includes a ResourcePatternResolver mechanism.
 *
 */
package org.springframework.core.io.support;

