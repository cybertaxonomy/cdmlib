
/**
 *
 * Core support package for Java 5 annotations.
 *
 */
package org.springframework.core.annotation;

