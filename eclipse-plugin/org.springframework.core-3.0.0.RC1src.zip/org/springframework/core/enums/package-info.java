
/**
 *
 * Interfaces and classes for type-safe enum support on JDK >= 1.3.
 * This enum abstraction support codes and labels.
 *
 */
package org.springframework.core.enums;

