
/**
 *
 * Useful generic <code>java.util.Comparator</code> implementations,
 * such as an invertible comparator and a compound comparator.
 *
 */
package org.springframework.util.comparator;

