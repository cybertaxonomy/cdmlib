
/**
 *
 * Contains an abstract XML-based <code>BeanFactory</code> implementation,
 * including a standard "spring-beans" DTD.
 *
 */
package org.springframework.beans.factory.xml;

