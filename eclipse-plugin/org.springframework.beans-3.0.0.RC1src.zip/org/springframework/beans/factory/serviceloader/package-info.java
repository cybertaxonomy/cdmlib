
/**
 *
 * Support package for the JDK 1.6 ServiceLoader facility.
 *
 */
package org.springframework.beans.factory.serviceloader;

