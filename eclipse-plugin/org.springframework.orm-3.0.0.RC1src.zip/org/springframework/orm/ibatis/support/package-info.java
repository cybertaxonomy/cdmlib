
/**
 *
 * Classes supporting the <code>org.springframework.orm.ibatis</code> package.
 * Contains a DAO base class for SqlMapClientTemplate usage.
 *
 */
package org.springframework.orm.ibatis.support;

