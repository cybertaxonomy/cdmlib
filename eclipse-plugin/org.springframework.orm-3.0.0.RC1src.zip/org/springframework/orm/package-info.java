
/**
 *
 * Root package for Spring's O/R Mapping integration classes.
 * Contains generic DataAccessExceptions related to O/R Mapping.
 *
 */
package org.springframework.orm;

