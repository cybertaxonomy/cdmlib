
/**
 *
 * Internal support for managing JPA persistence units.
 *
 */
package org.springframework.orm.jpa.persistenceunit;

