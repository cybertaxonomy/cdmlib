
/**
 *
 * Classes supporting the <code>org.springframework.orm.jpa</code> package.
 * Contains a DAO base class for JpaTemplate usage.
 *
 */
package org.springframework.orm.jpa.support;

