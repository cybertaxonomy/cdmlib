
/**
 *
 * Classes supporting the <code>org.springframework.orm.jdo</code> package.
 * Contains a DAO base class for JdoTemplate usage.
 *
 */
package org.springframework.orm.jdo.support;

