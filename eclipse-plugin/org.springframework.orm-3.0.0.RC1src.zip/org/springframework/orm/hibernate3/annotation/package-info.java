
/**
 *
 * Support package for the Hibernate3 Annotation add-on,
 * which supports EJB3-compliant JDK 1.5+ annotations for mappings.
 *
 */
package org.springframework.orm.hibernate3.annotation;

