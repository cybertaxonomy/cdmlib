
/**
 *
 * Classes supporting the <code>org.springframework.orm.hibernate3</code> package.
 * Contains a DAO base class for HibernateTemplate usage.
 *
 */
package org.springframework.orm.hibernate3.support;

