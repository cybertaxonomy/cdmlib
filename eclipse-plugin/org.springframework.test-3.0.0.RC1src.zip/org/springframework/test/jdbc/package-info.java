
/**
 *
 * Support classes for tests based on JDBC.
 *
 */
package org.springframework.test.jdbc;

