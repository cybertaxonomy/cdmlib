
/**
 *
 * This package contains the legacy JUnit 3.8 class hierarchy, which as of Spring 3.0
 * has been deprecated in favor of using the listener-based <em>Spring TestContext Framework</em>.
 *
 */
package org.springframework.test;

