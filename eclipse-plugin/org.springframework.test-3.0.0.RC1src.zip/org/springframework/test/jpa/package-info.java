
/**
 *
 * As of Spring 3.0, this package has been deprecated in favor of using the listener-based
 * <em>Spring TestContext Framework</em>.
 *
 */
package org.springframework.test.jpa;

