
/**
 *
 * <p>Support classes for ApplicationContext-based and transactional
 * tests run with TestNG and the <em>Spring TestContext Framework</em>.</p>
 *
 */
package org.springframework.test.context.testng;

