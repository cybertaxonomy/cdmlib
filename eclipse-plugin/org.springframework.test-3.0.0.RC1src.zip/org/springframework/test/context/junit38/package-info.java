
/**
 *
 * <p>Support classes for ApplicationContext-based and transactional
 * tests run with JUnit 3.8 and the <em>Spring TestContext Framework</em>.</p>
 *
 */
package org.springframework.test.context.junit38;

