/**
 * <p>Support classes for ApplicationContext-based and transactional
 * tests run with JUnit 4.5+ and the <em>Spring TestContext Framework</em>.</p>
 */

package org.springframework.test.context.junit4;

