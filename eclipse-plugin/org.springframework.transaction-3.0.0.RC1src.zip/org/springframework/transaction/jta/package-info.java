
/**
 *
 * Transaction SPI implementation for JTA.
 *
 */
package org.springframework.transaction.jta;

