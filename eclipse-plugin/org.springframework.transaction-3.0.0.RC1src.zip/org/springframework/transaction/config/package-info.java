
/**
 *
 * Support package for declarative transaction configuration,
 * with XML schema being the primary configuration format.
 *
 */
package org.springframework.transaction.config;

