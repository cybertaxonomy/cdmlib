
/**
 *
 * Provides a utility class for easy ConnectionFactory access,
 * a PlatformTransactionManager for local CCI transactions,
 * and various simple ConnectionFactory proxies/adapters.
 *
 */
package org.springframework.jca.cci.connection;

