
/**
 *
 * Classes supporting the <code>org.springframework.jca.cci.core</code> package.
 * Contains a DAO base class for CciTemplate usage.
 *
 */
package org.springframework.jca.cci.core.support;

