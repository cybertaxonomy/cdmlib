
/**
 *
 * Provides the core JCA CCI support, based on CciTemplate
 * and its associated callback interfaces.
 *
 */
package org.springframework.jca.cci.core;

