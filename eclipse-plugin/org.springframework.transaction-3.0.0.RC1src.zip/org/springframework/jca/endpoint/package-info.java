
/**
 *
 * This package provides a facility for generic JCA message endpoint management.
 *
 */
package org.springframework.jca.endpoint;

