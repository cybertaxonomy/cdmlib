
/**
 *
 * Convenience classes for scheduling based on the JCA 1.5 WorkManager facility,
 * as supported within JCA 1.5 ResourceAdapters.
 *
 */
package org.springframework.jca.work;

