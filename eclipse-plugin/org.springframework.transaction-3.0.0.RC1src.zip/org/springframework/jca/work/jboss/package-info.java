
/**
 *
 * Convenience package for obtaining a JBoss JCA WorkManager for use in
 * web applications. Provides a Spring TaskExecutor adapter for JBoss.
 *
 */
package org.springframework.jca.work.jboss;

