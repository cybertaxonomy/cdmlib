
/**
 *
 * Convenience package for obtaining a GlassFish JCA WorkManager for use in
 * web applications. Provides a Spring TaskExecutor adapter for GlassFish.
 *
 */
package org.springframework.jca.work.glassfish;

