
/**
 *
 * Integration package that allows for deploying a Spring application context
 * as a JCA 1.5 compliant RAR file.
 *
 */
package org.springframework.jca.context;

