
/**
 *
 * Support classes for JNDI usage,
 * including a JNDI-based BeanFactory implementation.
 *
 */
package org.springframework.jndi.support;

