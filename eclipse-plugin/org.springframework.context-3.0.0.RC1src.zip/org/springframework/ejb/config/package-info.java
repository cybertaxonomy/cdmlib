
/**
 *
 * Support package for EJB/J2EE-related configuration,
 * with XML schema being the primary configuration format.
 *
 */
package org.springframework.ejb.config;

