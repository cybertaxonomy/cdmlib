
/**
 *
 * Support classes for EJB 3 Session Beans and Message-Driven Beans,
 * performing injection of Spring beans through an EJB 3 interceptor
 * that processes Spring's <code>@Autowired</code> annotation.
 *
 */
package org.springframework.ejb.interceptor;

