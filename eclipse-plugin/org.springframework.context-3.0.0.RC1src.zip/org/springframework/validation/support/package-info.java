/**
 * Support classes for handling validation results.
 */
package org.springframework.validation.support;
