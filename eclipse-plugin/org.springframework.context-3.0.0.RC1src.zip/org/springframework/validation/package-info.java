/**
 * Provides data binding and validation functionality,
 * for usage in business and/or UI layers.
 */
package org.springframework.validation;
