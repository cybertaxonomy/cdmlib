
/**
 *
 * Support for class instrumentation on BEA WebLogic 10.
 *
 */
package org.springframework.instrument.classloading.weblogic;

