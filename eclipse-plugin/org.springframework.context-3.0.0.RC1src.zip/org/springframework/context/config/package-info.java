
/**
 *
 * Support package for advanced application context configuration,
 * with XML schema being the primary configuration format.
 *
 */
package org.springframework.context.config;

