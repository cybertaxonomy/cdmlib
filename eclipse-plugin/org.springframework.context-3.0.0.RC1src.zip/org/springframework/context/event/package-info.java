
/**
 *
 * Support classes for application events, like standard context events.
 * To be supported by all major application context implementations.
 *
 */
package org.springframework.context.event;

