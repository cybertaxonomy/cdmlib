
/**
 *
 * Generic support classes for remoting implementations.
 * Provides abstract base classes for remote proxy factories.
 *
 */
package org.springframework.remoting.support;

