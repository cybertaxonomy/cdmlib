
/**
 *
 * SOAP-specific exceptions and support classes for Spring's remoting subsystem.
 *
 */
package org.springframework.remoting.soap;

