
/**
 *
 * General exceptions for Spring's scheduling support,
 * independent of any specific scheduling system.
 *
 */
package org.springframework.scheduling;

