
/**
 *
 * JDK 1.5+ annotation for asynchronous method execution.
 *
 */
package org.springframework.scheduling.annotation;

