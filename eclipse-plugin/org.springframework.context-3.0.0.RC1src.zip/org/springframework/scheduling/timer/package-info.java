
/**
 *
 * Scheduling convenience classes for the JDK Timer,
 * allowing to set up Timers and ScheduledTimerTasks
 * as beans in a Spring context.
 *
 */
package org.springframework.scheduling.timer;

