
/**
 *
 * Provides generic JMX metadata classes and basic support for reading
 * JMX metadata in a provider-agnostic manner.
 *
 */
package org.springframework.jmx.export.metadata;

