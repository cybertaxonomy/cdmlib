
/**
 *
 * This package provides declarative creation and registration of
 * Spring-managed beans as JMX MBeans.
 *
 */
package org.springframework.jmx.export;

