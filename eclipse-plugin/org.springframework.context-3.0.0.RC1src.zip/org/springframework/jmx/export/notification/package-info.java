
/**
 *
 * Provides supporting infrastructure to allow Spring-created MBeans
 * to send JMX notifications.
 *
 */
package org.springframework.jmx.export.notification;

