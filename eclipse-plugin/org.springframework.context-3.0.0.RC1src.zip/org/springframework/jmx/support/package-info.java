
/**
 *
 * Contains support classes for connecting to local and remote <code>MBeanServer</code>s
 * and for exposing an <code>MBeanServer</code> to remote clients.
 *
 */
package org.springframework.jmx.support;

