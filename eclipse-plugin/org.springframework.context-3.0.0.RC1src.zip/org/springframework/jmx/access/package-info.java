
/**
 *
 * Provides support for accessing remote MBean resources. Requires JMX 1.2 or above.
 *
 */
package org.springframework.jmx.access;

