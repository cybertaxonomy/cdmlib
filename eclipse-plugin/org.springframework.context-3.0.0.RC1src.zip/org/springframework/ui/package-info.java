/**
 * Generic support for UI layer concepts.
 * Provides a generic ModelMap for model holding.
 */
package org.springframework.ui;
