/**
 * Support classes for the formatting package,
 * providing common implementations as well as adapters.
 */
package org.springframework.ui.format.support;
