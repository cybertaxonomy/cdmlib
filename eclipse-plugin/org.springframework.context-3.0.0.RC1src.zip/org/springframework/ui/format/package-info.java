/**
 * A SPI for defining Formatters to format field model values for display in a UI.
 */
package org.springframework.ui.format;
