
/**
 *
 * Core interfaces for Spring's scripting support.
 *
 */
package org.springframework.scripting;

