
/**
 *
 * Package providing integration of
 * <a href="http://groovy.codehaus.org">Groovy</a>
 * into Spring's scripting infrastructure.
 *
 */
package org.springframework.scripting.groovy;

