
/**
 *
 * Support package for Spring's dynamic language machinery,
 * with XML schema being the primary configuration format.
 *
 */
package org.springframework.scripting.config;

