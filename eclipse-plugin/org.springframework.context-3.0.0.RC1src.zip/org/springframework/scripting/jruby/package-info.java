
/**
 *
 * Package providing integration of
 * <a href="http://jruby.sourceforge.net">JRuby</a>
 * into Spring's scripting infrastructure.
 *
 */
package org.springframework.scripting.jruby;

