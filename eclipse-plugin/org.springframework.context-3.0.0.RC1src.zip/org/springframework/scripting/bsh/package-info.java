
/**
 *
 * Package providing integration of
 * <a href="http://www.beanshell.org">BeanShell</a>
 * into Spring's scripting infrastructure.
 *
 */
package org.springframework.scripting.bsh;

