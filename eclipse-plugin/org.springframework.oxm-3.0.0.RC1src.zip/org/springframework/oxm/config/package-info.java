
/**
 *
 * Provides an namespace handler for the Spring Object/XML namespace
 *
 */
package org.springframework.oxm.config;

