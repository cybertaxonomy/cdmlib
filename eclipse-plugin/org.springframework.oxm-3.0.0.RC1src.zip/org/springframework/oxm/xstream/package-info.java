
/**
 *
 * Package providing integration of <a href="http://xstream.codehaus.org/">XStream</a> with Springs O/X Mapping support
 *
 */
package org.springframework.oxm.xstream;

