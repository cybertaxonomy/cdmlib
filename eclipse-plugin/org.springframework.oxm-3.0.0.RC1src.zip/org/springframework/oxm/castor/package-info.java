
/**
 *
 * Package providing integration of <a href="http://www.castor.org/xml-mapping.html">Castor</a> within Springs O/X Mapping
 * support
 *
 */
package org.springframework.oxm.castor;

