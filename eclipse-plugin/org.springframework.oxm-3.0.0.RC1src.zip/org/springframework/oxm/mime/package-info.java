
/**
 *
 * Contains (un)marshallers optimized to store binary data in MIME attachments.
 * </htm
 *
 */
package org.springframework.oxm.mime;

