
/**
 *
 * Package providing integration of <a href="http://xmlbeans.apache.org/">XMLBeans</a> with Springs O/X Mapping support
 *
 */
package org.springframework.oxm.xmlbeans;

