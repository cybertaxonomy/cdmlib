
/**
 *
 * Package providing integration of <a href="http://jibx.sourceforge.net/">JiBX</a> with Springs O/X Mapping
 * support
 *
 */
package org.springframework.oxm.jibx;

