
/**
 *
 * Package providing integration of <a href="http://java.sun.com/webservices/jaxb/">JAXB</a> with Springs O/X Mapping
 * support
 *
 */
package org.springframework.oxm.jaxb;
