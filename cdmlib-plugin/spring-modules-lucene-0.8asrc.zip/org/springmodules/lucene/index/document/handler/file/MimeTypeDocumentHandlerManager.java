/*
 * Copyright 2002-2007 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.springmodules.lucene.index.document.handler.file;

import java.util.Iterator;
import java.util.Properties;
import java.util.Set;

import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springmodules.lucene.index.document.handler.DefaultDocumentHandlerManager;
import org.springmodules.lucene.index.document.handler.DocumentHandler;
import org.springmodules.lucene.index.document.handler.DocumentHandlerManager;
import org.springmodules.lucene.util.IOUtils;

/**
 * This class is the document handler manager which is based
 * on the mime types of files.
 * 
 * <p>It only adds the text document handler as default handlers.
 * 
 * @author Thierry Templier
 * @see org.springmodules.lucene.index.support.handler.ExtensionDocumentMatching
 * @see org.springmodules.lucene.index.support.handler.file.TextDocumentHandler
 */
public class MimeTypeDocumentHandlerManager extends DefaultDocumentHandlerManager implements DocumentHandlerManager {

	private static final String DOCUMENTHANDLER_EXTENSION_PROPERTIES
					= "org/springmodules/lucene/index/document/handler/file/documenthandler-mimetype.properties";
	private Resource documentHandlerProperties;

	/**
	 * Construct a new ExtensionDocumentHandlerManager.
	 */
	public MimeTypeDocumentHandlerManager() {
		super();
		setDocumentHandlerProperties(new ClassPathResource(DOCUMENTHANDLER_EXTENSION_PROPERTIES));
	}

	private Properties loadDocumentHandlerProperties() {
		return IOUtils.loadPropertiesFromResource(documentHandlerProperties);
	}
	
	/**
	 * This method adds the document handlers contained in the property file
	 * as default handlers.
	 * 
	 * @see org.springmodules.lucene.index.object.file.DocumentHandlerManager#registerDefautHandlers()
	 */
	public void registerDefaultHandlers() {
		Properties properties=loadDocumentHandlerProperties();
		Set mimeTypes=properties.keySet();
		for(Iterator i=mimeTypes.iterator();i.hasNext();) {
			String mimeType=(String)i.next();
			String documentHandlerClassName=(String)properties.get(mimeType);
			doRegisterDocumentHandler(mimeType, documentHandlerClassName);
		}
	}

	private void doRegisterDocumentHandler(String mimeType, String documentHandlerClassName) {
		try {
			Class documentHandlerClass = Class.forName(documentHandlerClassName);
			registerDocumentHandler(new MimeTypeDocumentMatching(mimeType),
						(DocumentHandler)documentHandlerClass.newInstance());
		} catch (ClassNotFoundException e) {
			//TODO: to be changed
			e.printStackTrace();
		} catch (InstantiationException e) {
			//TODO: to be changed
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			//TODO: to be changed
			e.printStackTrace();
		}
	}

	public Resource getDocumentHandlerProperties() {
		return documentHandlerProperties;
	}

	public void setDocumentHandlerProperties(Resource documentHandlerProperties) {
		this.documentHandlerProperties = documentHandlerProperties;
	}

}
